const app = Vue.createApp({
  data() {
    return {
      productTitle: "iPhone 15 Silicone Case with MagSafe - Light Blue",
      productPrice: (49.00).toFixed(2),
      productImage: "/images/G1.png",
      addedToCart: false,
      quantity: 1,
      cartItems: [], // Array to store added items
    };
  },
  computed: {
    totalCartPrice() {
      // Calculate the total price of all items in the cart
      return this.cartItems
        .reduce(
          (total, item) => total + parseFloat(item.price) * item.quantity,
          0
        )
        .toFixed(2);
    },
    totalCartQuantity() {
      // Calculate the total quantity of all items in the cart
      return this.cartItems.reduce((total, item) => total + item.quantity, 0);
    },
  },
  
  methods: {
    addToCart() {
      this.addedToCart = true;
      // Push the added item details into cartItems array
      this.cartItems.push({
        title: this.productTitle,
        image: this.productImage,
        price: this.productPrice,
        quantity: this.quantity,
      });
    },
    removeFromCart(index) {
      // Remove item from cartItems array at the specified index
      this.cartItems.splice(index, 1);
      // Hide cart if there are no items left
      if (this.cartItems.length === 0) {
        this.addedToCart = false;
      }
    },
  },
});

app.mount("#app");
